Well he collapsed of Stevens-Johnson syndrome on the E.R. floor. 

Now peep this one: [Link](https://de-slaug.github.io/cse15l-lab-reports/slop.html)

[CSE 15L Lab Report 1](https://de-slaug.github.io/cse15l-lab-reports/lrOne.html)

[CSE 15L Lab Report 2](https://de-slaug.github.io/cse15l-lab-reports/LabReportTwo.html)

[CSE 15L Lab Report 3](https://de-slaug.github.io/cse15l-lab-reports/LabReport3.html)

[CSE 15L Lab Report 4](https://de-slaug.github.io/cse15l-lab-reports/LabReportFour.html)
